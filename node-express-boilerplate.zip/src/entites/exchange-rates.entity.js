const EntitySchema = require("typeorm").EntitySchema;

module.exports = new EntitySchema({
    name: "ExchangeRates", // Will use table name `category` as default behaviour.
    tableName: "exchange-rates", // Optional: Provide `tableName` property to override the default behaviour for table name. 
    columns: {
        id: {
            primary: true,
            type: "int",
            generated: true
        },
        FROM: {
            type: "varchar"
        },
        TO: {
            type: "varchar"
        },
        TYPE: {
            type: "varchar"
        },
        MARKET: {
            type: "varchar"
        },
        FROMSYMBOL: {
            type: "varchar"
        },
        TOSYMBOL: {
            type: "varchar"
        },
        FLAGS: {
            type: "varchar"
        },
        PRICE: {
            type: "float"
        },
        LASTUPDATE: {
            type: "int"
        },
        MEDIAN: {
            type: "int"
        },
        LASTVOLUME: {
            type: "float"
        },
        LASTVOLUMETO: {
            type: "float"
        },
        LASTTRADEID: {
            type: "varchar"
        },
        VOLUMEDAY: {
            type: "float"
        },
        VOLUMEDAYTO: {
            type: "float"
        },
        VOLUME24HOUR: {
            type: "float"
        },
        VOLUME24HOURTO: {
            type: "float"
        },
        OPENDAY: {
            type: "float"
        },
        HIGHDAY: {
            type: "float"
        },
        LOWDAY: {
            type: "float"
        },
        OPEN24HOUR: {
            type: "float"
        },
        HIGH24HOUR: {
            type: "int"
        },
        LOW24HOUR: {
            type: "float"
        },
        LASTMARKET: {
            type: "varchar"
        },
        VOLUMEHOUR: {
            type: "float"
        },
        VOLUMEHOURTO: {
            type: "float"
        },
        OPENHOUR: {
            type: "float"
        },
        HIGHHOUR: {
            type: "float"
        },
        LOWHOUR: {
            type: "float"
        },
        TOPTIERVOLUME24HOUR: {
            type: "float"
        },
        TOPTIERVOLUME24HOURTO: {
            type: "float"
        },
        CHANGE24HOUR: {
            type: "float"
        },
        CHANGEPCT24HOUR: {
            type: "float"
        },
        CHANGEDAY: {
            type: "float"
        },
        CHANGEPCTDAY: {
            type: "float"
        },
        CHANGEHOUR: {
            type: "float"
        },
        CHANGEPCTHOUR: {
            type: "float"
        },
        CONVERSIONTYPE: {
            type: "varchar"
        },
        CONVERSIONSYMBOL: {
            type: "varchar"
        },
        SUPPLY: {
            type: "int"
        },
        MKTCAP: {
            type: "float"
        },
        MKTCAPPENALTY: {
            type: "float"
        },
        CIRCULATINGSUPPLY: {
            type: "float"
        },
        CIRCULATINGSUPPLYMKTCAP: {
            type: "float"
        },
        TOTALVOLUME24H: {
            type: "float"
        },
        TOTALVOLUME24HTO: {
            type: "float"
        },
        TOTALTOPTIERVOLUME24H: {
            type: "float"
        },
        TOTALTOPTIERVOLUME24HTO: {
            type: "float"
        },
        IMAGEURL: {
            type: "varchar"
        },
    }
});